document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.sidebar');
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const closeBtn = document.querySelector('.close-btn');
    const form = document.getElementById('review-form');

    if (sidebar && sidebarToggle && closeBtn) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.style.left = sidebar.style.left === '0px' ? '-250px' : '0px';
        });

        closeBtn.addEventListener('click', () => {
            sidebar.style.left = '-250px';
        });
    }

    if (form) {
        form.addEventListener('submit', async (event) => {
            event.preventDefault();

            const name = document.getElementById('name').value;
            const rating = document.getElementById('rating').value;
            const comments = document.getElementById('comments').value;

            const reviewData = {
                content: `تقييم جديد:\nاسم: ${name}\nتقييم: ${rating}\nملاحظات: ${comments}`
            };

            try {
                await fetch('https://discord.com/api/webhooks/1279952406515417171/ugRptfeSjjWE4Lyh3V8nmXKiYvqxgnCmXt97Gwd9A35lls2gIuBLCg3oPDaerNsyv-N4', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(reviewData)
                });

                alert('تم إرسال تقييمك بنجاح!');
                form.reset();
            } catch (error) {
                console.error('حدث خطأ أثناء إرسال التقييم:', error);
                alert('فشل في إرسال تقييمك، حاول مرة أخرى.');
            }
        });
    }
});
